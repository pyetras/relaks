package relaks.dsl

/**
 * Created by Pietras on 11/04/15.
 */

import relaks.dsl.AST._
import org.scalatest._

class OperationsTest extends FunSpec with Matchers with Inside {
  describe("Rep extensions") { pending
//    describe("should build a tree for") {
//      it("comparison operators") {
//        val x: Rep[ScalaType[Int]] = 1
//        val y = x < 5
//        inside(y.tree) { case Apply(Operator("<"), lst: List[Expression]) =>
//          lst should matchPattern { case hd :: tl if tl == List(Literal(Constant(5))) => } }
//
//      }
//    }
  }

}
