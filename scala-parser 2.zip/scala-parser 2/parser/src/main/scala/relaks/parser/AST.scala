package relaks.parser

import relaks.ast.ASTNodes

import scala.util.parsing.input.Positional

/**
 * Created by Pietras on 13/04/15.
 */
object AST extends ASTNodes{
}
